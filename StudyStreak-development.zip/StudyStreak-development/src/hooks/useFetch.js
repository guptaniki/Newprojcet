import ajaxCall from "../helpers/ajaxCall";

const useFetch = () => {
  ajaxCall();
};

export default useFetch;
